import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: "AIzaSyDtIjNXObkuYBzqKyenSNphy9JDPz83oA8" });

async function main(pregunta) {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: pregunta ,
  });
  console.log(response.text);
}

main("¿Qué día será mañana?");




